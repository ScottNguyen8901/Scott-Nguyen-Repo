The analysis script runs the analysis for the polynomial coefficients and the histograms, contours, etc. 
That is used in the main script. The main script calls the rpm_predictor which has the parameters as a 
class for a modular approach. The main script calls the state variables and calculates the rpm and 
compares it with the test data.