import json
from http.server import BaseHTTPRequestHandler, HTTPServer

class Handler(BaseHTTPRequestHandler):
    def _ok(self, body=b"OK", content_type="text/plain"):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/", "/status"):
            self._ok(b'{"ok": true}\n', "application/json")
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode()

        if self.path == "/status":
            print("\nReceived POST to /status", flush=True)
            print("----- BEGIN PAYLOAD -----", flush=True)
            print(body, flush=True)
            print("------ END PAYLOAD ------", flush=True)
            self._ok()
        elif self.path == "/program":
            try:
                data = json.loads(body)
                with open("schedule.txt", "w") as f:
                    for entry in data:
                        f.write(f"{entry['time']} {entry['temp']:.1f}\n")

                print("\nUpdated schedule.txt from POST to /program", flush=True)
                print("----- BEGIN SCHEDULE -----", flush=True)
                with open("schedule.txt") as f:
                    print(f.read().strip(), flush=True)
                print("------ END SCHEDULE ------", flush=True)
                self._ok()
            except Exception as e:
                self.send_response(400)
                self.end_headers()
                print(f"Error parsing /program POST: {e}", flush=True)
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == "__main__":
    host, port = "0.0.0.0", 8000
    print(f"HTTP test server running on http://{host}:{port} ...", flush=True)
    HTTPServer((host, port), Handler).serve_forever()
